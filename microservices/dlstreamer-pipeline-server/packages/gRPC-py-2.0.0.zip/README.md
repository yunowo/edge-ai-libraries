# Contents

- [Contents](#contents)
  - [EII gRPC library](#eii-grpc-library)
    - [Dependency Installation](#dependency-installation)
    - [Testing](#testing)


## EII gRPC library

This library APIs can be used to send/receive messages(metadata/blob/both) from one EII service to another via gRPC.

### Dependency Installation

Please install the required dependencies by running the commands given below:

```sh
python -m pip install --upgrade pip

python -m pip install grpcio

python -m pip install grpcio-tools
```

### Compiling the proto file to generate boiler-plate gRPC code

Run this command from the protos directory to generate the boiler-plate code in python:

```sh
python -m grpc_tools.protoc -I./ --python_out=. --pyi_out=. --grpc_python_out=. ./grpc.proto
```


### Testing

You can run the existing server client samples in 2 different terminals each.

Run the test_server_recv.py by running the commands below from the test directory:

```sh
export PYTHONPATH=$PYTHONPATH:../:../protos

python3 test_server_recv.py
```

Run the test_server_recv.py by running the commands below for using callback method:

``` sh
export PYTHONPATH=$PYTHONPATH:../:../protos

python3 test_server_recv.py --callback true

#Note: Make sure the callback is implemented by the application

````

Run the test_client_send.py by running the commands below:

```sh
export PYTHONPATH=$PYTHONPATH:../:../protos

python3 test_client_send.py

```
