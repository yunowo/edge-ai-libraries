# Copyright Intel Corporation
"""The Python implementation of the EdgeGrpcService server.
"""

from concurrent import futures

import grpc
import grpc_pb2
import grpc_pb2_grpc
import asyncio
import os
import queue
import time
import json
import threading
import logging
from distutils.util import strtobool

MAX_LENGTH = 1024 * 1024 * 1000 # 1000 MB

FRAME_QUEUE_SIZE = 2 # ping-pong buffer

MAX_WORKERS = os.cpu_count()

if MAX_WORKERS is None:
    MAX_WORKERS = 8

frame_mutex = threading.Lock()

class GrpcService(grpc_pb2_grpc.GrpcServiceServicer):
    """EdgeGrpcService class
    """

    def __init__(self, callback=None, input_queue=None, log=None, profiling_mode=None):
        """Constructor

        :param str input_queue: Input queue containing messages to be sent by server
        """
        self.callback = callback
        self.input_queue = input_queue
        self.log = log
        self.profiling_mode = profiling_mode

    # Each EII service can define its own such method defining what
    # the server needs to do when it receives a request from the client
    def streamData(self, request, context):
        """Server API to send metadata or blob

        .. note:: User can define his own APIs here based on what he wants to
           serve w.r.t each client request

        """
        try:
            if request is None:
                raise Exception("gRPC request message is None")
            msg = self._get_msg(request)
            if self.callback is None:
                with frame_mutex:
                    if self.input_queue.full():
                        old_msg = self.input_queue.get()
                        del old_msg
                    if self.profiling_mode:
                        metadata, blob =  msg
                        metadata['gRPC_server_adding_message_to_queue'] = time.time_ns()
                        msg = metadata, blob
                    self.input_queue.put(msg)
                    self.log.debug("Msg added to input queue")
            else:
                if self.profiling_mode:
                    metadata, blob =  msg
                    metadata['gRPC_server_triggering_callback'] = time.time_ns()
                    msg = metadata, blob
                self.callback(msg)

            response = grpc_pb2.status(ret = True)
            return response
        except Exception as e:
            self.log.error("Exception in gRPC streamData method:{}".format(e))
            response = grpc_pb2.status(ret = False)
            return response


    def _get_msg(self, request):
        for req in request:
            msg = (json.loads(req.metadata), req.blob)
            return msg

class Server:
    """Edge gRPC Server class
    """
    def __init__(self, port=None, dev_mode='True', callback=None, queue_size=FRAME_QUEUE_SIZE, max_workers=MAX_WORKERS, log=None):
        """Constructor

        :param str port: port to serve
        :param str dev_mode: Dev mode variable
        """
        self.port = port
        self.server = None
        self.input_queue = None
        self.callback = callback

        #create and configure logger
        if log is None:
            logging.basicConfig(format='%(asctime)s %(message)s')
            self.log = logging.getLogger()
            self.log.setLevel(logging.INFO)
        else:
            self.log = log

        if max_workers is None:
            self.log.info("gRPC server max workers cannot be None. Using default max workers")
            self.max_workers = MAX_WORKERS
        elif max_workers < 4:
            self.log.info("gRPC server max workers is less than 4. Using default max workers")
            self.max_workers = MAX_WORKERS
        else:
            self.max_workers = max_workers
        self.log.info("gRPC server max workers :{}".format(self.max_workers))

        if queue_size is None:
            self.log.info("Frame queue size cannot be None. Using default frame queue size.")
            self.queue_size = FRAME_QUEUE_SIZE
        elif queue_size < 1:
            self.log.info("Minimum frame queue size input should be 1. Using default frame queue size.")
            self.queue_size = FRAME_QUEUE_SIZE
        else:
            self.queue_size = queue_size

        self.log.info("Frame queue size : {}".format(self.queue_size))

        if dev_mode.lower() == 'true':
            self.dev_mode = True
        elif dev_mode.lower() == 'false':
            self.dev_mode = False
        else:
            self.log.error("DEV_MODE value:{} not supported".format(self.dev_mode))

        self.profiling_mode = bool(strtobool(os.getenv('PROFILING_MODE', 'false')))
        self.log.debug("Profiling mode: {}".format(self.profiling_mode))

        if self.callback is None:
            self.input_queue = queue.Queue(maxsize=self.queue_size)
        server_thread = threading.Thread(target=self._start_server)
        server_thread.start()


    def _start_server(self):
        """Method to start the gRPC server

        """

        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=self.max_workers), \
                                  options = (('grpc.max_send_message_length', MAX_LENGTH),  \
                                             ('grpc.max_receive_message_length', MAX_LENGTH),))

        grpc_pb2_grpc.add_GrpcServiceServicer_to_server(GrpcService(self.callback, self.input_queue, self.log, self.profiling_mode), self.server)

        if self.dev_mode:
            self.server.add_insecure_port('[::]:' + self.port)
            self.log.info("Insecure connection enabled for gRPC server")
        else:
            # Fetch and append Server certificate and key
            secrets_prefix = '/run/secrets/' + os.environ['AppName'] + '_gRPC' + '/' + os.environ['AppName']
            with open(secrets_prefix + '_gRPC_server_key.pem', 'rb') as f:
                private_key = f.read()
            with open(secrets_prefix + '_gRPC_server_certificate.pem', 'rb') as f:
                certificate_chain = f.read()
            with open('/run/secrets/' + os.environ['AppName'] + '_gRPC' + '/' + 'cacert.pem', 'rb') as f:
                root_certificates = f.read()
            server_credentials = grpc.ssl_server_credentials([(private_key,certificate_chain)],
                                                             root_certificates=root_certificates,
                                                             require_client_auth=True)
            # Start secure server
            self.server.add_secure_port('[::]:' + self.port, server_credentials)
            self.log.info("Secure connection enabled for gRPC server")
        self.server.start()
        self.log.info("gRPC server started, listening on {}".format(self.port))
        self.server.wait_for_termination()

    def receive(self):
        """Method called by the application to receive the frames

        """
        if self.callback is None:
            with frame_mutex:
                if not self.input_queue.empty() :
                    if self.profiling_mode:
                        msg = self.input_queue.get()
                        metadata, blob =  msg
                        metadata['gRPC_message_get_from_queue'] = time.time_ns()
                        msg = metadata, blob
                        return msg
                    else:
                        return self.input_queue.get()
                else:
                    self.log.debug("Input queue is empty. Returning None")
                    return None

        else:
            self.log.error("Callback function enabled and receive method will not be supported")

    def __del__(self):
        """Destructor

        """
        self.server.stop()
        self.log.info("gRPC server stopped")
