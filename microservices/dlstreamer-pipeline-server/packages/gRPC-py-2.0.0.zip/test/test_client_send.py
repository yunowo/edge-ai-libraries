# Copyright Intel Corporation
"""Edge gRPC client test script.
"""

import logging
import os
from edge_grpc_client import Client
import numpy as np
import json
import asyncio
import time
import logging
import grpc

def main():

    logging.basicConfig(format='%(asctime)s %(message)s')
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logging.getLogger('asyncio').setLevel(logging.WARNING)

    # Connect to Server running at localhost and port 50051
    app = Client(host="localhost", port="50051", dev_mode=os.getenv("DEV_MODE", "True"), log=logger, timeout=60)

    # For connecting to multiple servers
    #app2 = Client(host="localhost", port="50052", dev_mode=os.getenv("DEV_MODE", "True"))

    blob = np.zeros((1080,1920,3), dtype=np.uint8)

    retry_count = 0
    max_retry_count = 5

    for i in range(1000):
        metadata = {
        'height': blob.shape[0],
        'width': blob.shape[1],
        'channels': blob.shape[2],
        'camera_stream': 'stream1',
        'frame_count': i + 1
        }
        response, err = asyncio.run(app.send(metadata, blob.tobytes()))
        #ret = asyncio.run(app.send(metadata, None))
        #ret = asyncio.run(app.send(None, blob.tobytes()))
        #app2.send(metadata,blob)
        while (err is not None and retry_count < max_retry_count):
            if err == grpc.StatusCode.DEADLINE_EXCEEDED:
                logger.error("gRPC error: Deadline expired before server returned status")
            elif err == grpc.StatusCode.UNAVAILABLE:
                logger.error("gRPC error: Server shutting down")
            elif err == grpc.StatusCode.CANCELLED:
                logger.error("gRPC error: Client application cancelled the request")
            elif err == grpc.StatusCode.UNIMPLEMENTED:
                logger.error("gRPC error: Method not found on server")
            elif err == grpc.StatusCode.UNKNOWN:
                logger.error("gRPC error: Server threw an exception")
            else:
                logger.error("Received {} error code".format(err))
            retry_count += 1
            # Re-send the data
            logger.debug("Re-sending data ...")
            response, err = asyncio.run(app.send(metadata, blob.tobytes()))

        if retry_count == max_retry_count:
             logger.error("Unable to send gRPC message with metadata:{} \
                           after max_retry_count:{}".format(metadata, max_retry_count))
             # Exit application loop if send fails after max retries
             break

        logger.info("Response :{}".format(response))
        time.sleep(0.016)

if __name__ == '__main__':
    main()
