# Copyright Intel Corporation
"""Edge gRPC server test script.
"""

import logging
import queue
import os
from edge_grpc_server import Server
import asyncio
import threading
import multiprocessing
import time
import numpy as np
import argparse
import logging

def callback(msg):
    if msg is not None:
        metadata, blob =  msg
        img = np.frombuffer(blob, dtype=np.uint8)
        frame = np.reshape(
            img, (
                metadata['height'],
                metadata['width'],
                metadata['channels']
                )
            )
        print("metadata in test server :{}".format(metadata))
        print("frame shape :{}".format(frame.shape))


def main():

    logging.basicConfig(format='%(asctime)s %(message)s')
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    parser = argparse.ArgumentParser()

    parser.add_argument("-c", "--callback", help = "callback method enabled for receiving frame")

    args = parser.parse_args()

    if args.callback == "true":
        app = Server(port="50051", dev_mode=os.getenv("DEV_MODE", "True"), callback=callback, queue_size=2, log=logger)
        print("callback is enabled")
        time.sleep(86400)
    else:
        print("callback not enabled")
        app = Server(port="50051", dev_mode=os.getenv("DEV_MODE", "True"), callback=None, queue_size=2, max_workers=8, log=logger)
        while True:
            msg =  app.receive()
            if msg is not None:
                metadata, blob = msg
                img = np.frombuffer(blob, dtype=np.uint8)
                '''
                frame = np.reshape(
                    img, (
                        metadata['height'],
                        metadata['width'],
                        metadata['channels']
                        )
                    )
                print("metadata in test server :{}".format(metadata))
                print("frame shape :{}".format(frame.shape))
                '''
                print("metadata : {}".format(metadata))
                print("blob len : {}".format(len(blob)))
            else:
                # Sleep for 10 milliseconds when message is None
                time.sleep(0.01)

if __name__ == '__main__':
    main()
