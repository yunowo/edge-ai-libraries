#!/bin/bash
# Copyright Intel Corporation
export AppName="Test"
export PYTHONPATH=$PYTHONPATH:../:../protos
coverage run -m pytest
