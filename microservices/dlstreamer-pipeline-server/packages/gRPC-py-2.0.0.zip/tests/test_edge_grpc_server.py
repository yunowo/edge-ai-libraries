import unittest
from unittest.mock import MagicMock, patch
from edge_grpc_server import GrpcService, Server
import grpc_pb2

class TestGrpcService(unittest.TestCase):

    def setUp(self):
        self.callback = MagicMock()
        self.input_queue = MagicMock()
        self.log = MagicMock()
        self.profiling_mode = False
        self.grpc_service = GrpcService(callback=self.callback, input_queue=self.input_queue, log=self.log, profiling_mode=self.profiling_mode)

    def test_streamData_with_callback(self):
        request = MagicMock()
        context = MagicMock()
        self.grpc_service._get_msg = MagicMock(return_value=("metadata", "blob"))

        response = self.grpc_service.streamData(request, context)

        self.callback.assert_called_once_with(("metadata", "blob"))
        self.assertTrue(response.ret)

    def test_streamData_without_callback(self):
        self.grpc_service.callback = None
        request = MagicMock()
        context = MagicMock()
        self.grpc_service._get_msg = MagicMock(return_value=("metadata", "blob"))

        self.input_queue.full.return_value = False

        response = self.grpc_service.streamData(request, context)

        self.input_queue.put.assert_called_once_with(("metadata", "blob"))
        self.assertTrue(response.ret)

    def test_streamData_exception(self):
        request = None
        context = MagicMock()

        response = self.grpc_service.streamData(request, context)

        self.log.error.assert_called_once()
        self.assertFalse(response.ret)

class TestServer(unittest.TestCase):

    @patch('edge_grpc_server.grpc.server')
    @patch('edge_grpc_server.futures.ThreadPoolExecutor')
    def setUp(self, mock_executor, mock_grpc_server):
        self.port = "50051"
        self.dev_mode = 'True'
        self.callback = MagicMock()
        self.queue_size = 2
        self.max_workers = 4
        self.log = MagicMock()
        self.server = Server(port=self.port, dev_mode=self.dev_mode, callback=self.callback, queue_size=self.queue_size, max_workers=self.max_workers, log=self.log)

    def test_server_initialization(self):
        self.assertEqual(self.server.port, self.port)
        self.assertEqual(self.server.dev_mode, True)
        self.assertEqual(self.server.queue_size, self.queue_size)
        self.assertEqual(self.server.max_workers, self.max_workers)

    @patch('edge_grpc_server.grpc.ssl_server_credentials')
    @patch('edge_grpc_server.open')
    @patch('edge_grpc_server.os.getenv')
    def test_start_server_secure(self, mock_getenv, mock_open, mock_ssl_server_credentials):
        mock_getenv.return_value = 'AppName'
        mock_open.side_effect = [MagicMock(read=MagicMock(return_value=b'data'))] * 3
        self.server.dev_mode = False

    def test_receive_with_callback(self):
        self.server.callback = MagicMock()

        with self.assertRaises(Exception):
            self.server.receive()
            raise

    def test_receive_without_callback(self):
        self.server.callback = None
        self.server.input_queue = MagicMock()
        self.server.input_queue.empty.return_value = False
        self.server.input_queue.get.return_value = ("metadata", "blob")

        msg = self.server.receive()

        self.assertEqual(msg, ("metadata", "blob"))

if __name__ == '__main__':
    unittest.main()