import unittest
import asyncio
import json
import grpc
from unittest.mock import patch, MagicMock
from edge_grpc_client import Client

class TestClient(unittest.TestCase):

    @patch('edge_grpc_client.grpc.insecure_channel')
    @patch('edge_grpc_client.grpc_pb2_grpc.GrpcServiceStub')
    def test_init_insecure_channel(self, mock_stub, mock_insecure_channel):
        client = Client(host='localhost', port='50051', dev_mode='true')
        mock_insecure_channel.assert_called_once_with('localhost:50051', options=(
            ('grpc.max_send_message_length', 1024 * 1024 * 1000),
            ('grpc.max_receive_message_length', 1024 * 1024 * 1000),
        ))
        mock_stub.assert_called_once()

    @patch('edge_grpc_client.grpc.ssl_channel_credentials')
    @patch('edge_grpc_client.grpc.secure_channel')
    @patch('builtins.open', new_callable=unittest.mock.mock_open, read_data=b'data')
    @patch.dict('os.environ', {'AppName': 'test_app'})
    def test_init_secure_channel(self, mock_open, mock_secure_channel, mock_ssl_channel_credentials):
        mock_ssl_channel_credentials.return_value = MagicMock()
        client = Client(host='localhost', port='50051', dev_mode='false')
        mock_open.assert_any_call('/run/secrets/test_app_gRPC/cacert.pem', 'rb')
        mock_open.assert_any_call('/run/secrets/test_app_gRPC/test_app_gRPC_server_certificate.pem', 'rb')
        mock_open.assert_any_call('/run/secrets/test_app_gRPC/test_app_gRPC_server_key.pem', 'rb')
        mock_ssl_channel_credentials.assert_called_once()
        mock_secure_channel.assert_called_once_with('localhost:50051', mock_ssl_channel_credentials(),
                                                    options=(
                                                        ('grpc.ssl_target_name_override', 'localhost'),
                                                        ('grpc.max_send_message_length', 1024 * 1024 * 1000),
                                                        ('grpc.max_receive_message_length', 1024 * 1024 * 1000),
                                                    ))

    @patch('edge_grpc_client.grpc_pb2_grpc.GrpcServiceStub')
    def test_send(self, mock_stub):
        client = Client(host='localhost', port='50051', dev_mode='true')
        mock_stub.return_value.streamData = MagicMock(return_value='response')
        metadata = {"key": "value"}
        blob = b'blob_data'
        response, error = asyncio.run(client.send(metadata, blob))
        self.assertEqual(response, 'response')
        self.assertIsNone(error)

    @patch('edge_grpc_client.grpc_pb2_grpc.GrpcServiceStub')
    def test_request_data(self, mock_stub):
        client = Client(host='localhost', port='50051', dev_mode='true')
        mock_stub.return_value.requestData = MagicMock(return_value='response')
        request = "test_request"
        response, error = client.request_data(request)
        self.assertEqual(response, 'response')
        self.assertIsNone(error)

    @patch('edge_grpc_client.grpc.insecure_channel')
    @patch('edge_grpc_client.grpc_pb2_grpc.GrpcServiceStub')
    def test_del(self, mock_stub, mock_insecure_channel):
        client = Client(host='localhost', port='50051', dev_mode='true')
        with patch.object(client.channel, 'close', return_value=None) as mock_close:
            del client
            mock_close.assert_called_once()

    @patch('edge_grpc_client.grpc_pb2.msgData')
    def test_get_msg(self, mock_msgData):
        client = Client(host='localhost', port='50051', dev_mode='true')
        metadata = {"key": "value"}
        blob = b'blob_data'
        mock_msgData.return_value = 'mocked_message'

        generator = client._get_msg(metadata, blob)
        message = next(generator)

        mock_msgData.assert_called_once_with(metadata=json.dumps(metadata), blob=blob)
        self.assertEqual(message, 'mocked_message')

    @patch('edge_grpc_client.grpc_pb2.msgData')
    def test_get_msg_exception(self, mock_msgData):
        client = Client(host='localhost', port='50051', dev_mode='true')
        metadata = {"key": "value"}
        blob = b'blob_data'
        mock_msgData.side_effect = Exception("Test Exception")

        with self.assertRaises(Exception) as context:
            generator = client._get_msg(metadata, blob)
            next(generator)

        self.assertTrue("Test Exception" in str(context.exception))

    @patch('edge_grpc_client.grpc_pb2_grpc.GrpcServiceStub')
    def test_request_data(self, mock_stub):
        client = Client(host='localhost', port='50051', dev_mode='true')
        mock_stub.return_value.requestData = MagicMock(return_value='response')
        request = "test_request"
        response, error = client.request_data(request)
        self.assertEqual(response, 'response')
        self.assertIsNone(error)

    @patch('edge_grpc_client.grpc.insecure_channel')
    @patch('edge_grpc_client.grpc_pb2_grpc.GrpcServiceStub')
    def test_del(self, mock_stub, mock_insecure_channel):
        client = Client(host='localhost', port='50051', dev_mode='true')
        with patch.object(client.channel, 'close', return_value=None) as mock_close:
            del client
            mock_close.assert_called_once()

    @patch('edge_grpc_client.grpc_pb2.msgData')
    def test_get_msg(self, mock_msgData):
        client = Client(host='localhost', port='50051', dev_mode='true')
        metadata = {"key": "value"}
        blob = b'blob_data'
        mock_msgData.return_value = 'mocked_message'

        generator = client._get_msg(metadata, blob)
        message = next(generator)

        mock_msgData.assert_called_once_with(metadata=json.dumps(metadata), blob=blob)
        self.assertEqual(message, 'mocked_message')

    @patch('edge_grpc_client.grpc_pb2.msgData')
    def test_get_msg_exception(self, mock_msgData):
        client = Client(host='localhost', port='50051', dev_mode='true')
        metadata = {"key": "value"}
        blob = b'blob_data'
        mock_msgData.side_effect = Exception("Test Exception")

        with self.assertRaises(Exception) as context:
            generator = client._get_msg(metadata, blob)
            next(generator)

        self.assertTrue("Test Exception" in str(context.exception))

if __name__ == '__main__':
    unittest.main()
