# Copyright Intel Corporation
"""The Python implementation of the EdgeGrpcService client.
"""

import os
import time
import grpc
import grpc_pb2
import grpc_pb2_grpc
import asyncio
import json
import logging
from distutils.util import strtobool

MAX_LENGTH = 1024 * 1024 * 1000 # 1000 MB

WAIT_FOR_READY_TIMEOUT_SECS = 30 # 30 secs

class Client:
    """Edge gRPC Client class
    """
    def __init__(self, host=None, port=None, dev_mode=None, log=None, timeout=WAIT_FOR_READY_TIMEOUT_SECS):
        """Constructor

        :param str host: host IP to send request
        :param str port: port to send request
        :param str dev_mode: Dev mode variable
        """
        self.host = host
        self.port = port
        self.stub = None

        #create and configure logger
        if log is None:
            logging.basicConfig(format='%(asctime)s %(message)s')
            self.log = logging.getLogger()
            self.log.setLevel(logging.INFO)
        else:
            self.log = log

        if dev_mode.lower() == 'true':
            self.dev_mode = True
        elif dev_mode.lower() == 'false':
            self.dev_mode = False
        else:
            self.log.error("DEV_MODE value:{} not supported".format(self.dev_mode))

        if timeout is None:
            self.log.debug("Wait for ready timeout is None.\
                           Using default value : {}".format(WAIT_FOR_READY_TIMEOUT_SECS))
            self.timeout = WAIT_FOR_READY_TIMEOUT_SECS
        elif timeout > 0:
            self.timeout = timeout
        else:
            self.log.debug("Wait for ready timeout is not provided. \
                           Using default value : {}".format(WAIT_FOR_READY_TIMEOUT_SECS))
            self.timeout = WAIT_FOR_READY_TIMEOUT_SECS
        self.log.info("Wait for ready timeout is {}".format(self.timeout))


        self.profiling_mode = bool(strtobool(os.getenv('PROFILING_MODE', 'false')))
        self.log.debug("Profiling mode: {}".format(self.profiling_mode))

        self.log.info("Connecting to server at " + self.host + ":" + self.port)
        if self.dev_mode:
            self.channel = grpc.insecure_channel(self.host + ':' + self.port,
                                          options = (('grpc.max_send_message_length', MAX_LENGTH),
                                                     ('grpc.max_receive_message_length', MAX_LENGTH),))
            self.log.info("gRPC client connected to insecure channel")
        else:
            # Fetch and append cacert and client certificate/key
            appname = os.environ['AppName']
            if appname is None:
                self.log.error("Appname environment variable is not set")
            secrets_prefix = '/run/secrets/' + appname + '_gRPC'
            with open(secrets_prefix + '/cacert.pem', 'rb') as cacert,\
                 open(secrets_prefix + '/'+ appname + '_gRPC_server_certificate.pem', 'rb') as cert,\
                 open(secrets_prefix + '/'+ appname + '_gRPC_server_key.pem', 'rb') as key:
                creds = grpc.ssl_channel_credentials(certificate_chain=cert.read(), private_key=key.read(),
                                                     root_certificates=cacert.read())
            # TODO: Check if peer name can be obtaied from certificate
            # Required to fix peer name not present in certificate issue
            cert_cn = "localhost"
            self.channel = grpc.secure_channel(self.host + ':' + self.port, creds,
                                          options=(('grpc.ssl_target_name_override', cert_cn,),
                                                   ('grpc.max_send_message_length', MAX_LENGTH),
                                                   ('grpc.max_receive_message_length', MAX_LENGTH),))
            self.log.info("gRPC client connected to secure channel")
        self.stub = grpc_pb2_grpc.GrpcServiceStub(self.channel)


    async def send(self, metadata, blob):
        """Method to send client streaming request message

        :param string metadata: metadata associated with the frame
        :param bytes blob: bytes data of the frame
        """
        if self.profiling_mode:
            metadata["gRPC_client_send"] = time.time_ns()
        request = self._get_msg(metadata, blob)

        try:
            response = self.stub.streamData(request, timeout=self.timeout, wait_for_ready=True)
            return response, None
        except grpc.RpcError as rpc_error:
            self.log.error(rpc_error)
            return None, rpc_error.code()


    def _get_msg(self, metadata, blob):
        """Method to generate client streaming request message

        :param string metadata: metadata associated with the frame
        :param bytes blob: bytes data of the frame
        """
        try :
            yield grpc_pb2.msgData(metadata = json.dumps(metadata), blob = blob)
        except Exception as e:
            self.log.error(e)
            raise

    def request_data(self, request=""):
        """Method to request DataStore Server's CommandProcessingLayer APIs

        :param str request: request payload
        """
        try:
            # Send request to server
            response = self.stub.requestData(grpc_pb2.clientRequest(request_string=request),\
                                                     timeout=self.timeout, wait_for_ready=True)
            return response, None
        except grpc.RpcError as rpc_error:
            self.log.error(rpc_error)
            return None, rpc_error.code()

    def __del__(self):
        """ Destructor
        """
        self.channel.close()
        self.log.info("gRPC channel closed")
