// Copyright Intel Corporation

/**
 * @file
 * @brief Resize UDF Implementation
 */

#include <eii/udf/base_udf.h>
#include <eii/utils/logger.h>
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace eii::udf;

namespace eii {
    namespace udfsamples {

    /**
     * The Resize UDF
     */
        class ResizeUdf : public BaseUdf {
            private:
                int m_width;
                int m_height;

            public:
                explicit ResizeUdf(config_t* config): BaseUdf(config) {
                    config_value_t* width = m_config->get_config_value(m_config->cfg, "width");
                    if (width == NULL) {
                        throw "Failed to get width";
                    }
                    if (width->type != CVT_INTEGER) {
                        throw "width must be an integer";
                    }

                    config_value_t* height = m_config->get_config_value(m_config->cfg, "height");

                    if (height == NULL) {
                    throw "Failed to get height";
                    }
                    if (height->type != CVT_INTEGER) {
                        throw "height must be an integer";
                    }

                    m_width = width->body.integer;
                    m_height = height->body.integer;

                };

                ~ResizeUdf() {};

                UdfRetCode process(cv::Mat& frame, cv::Mat& output,
                                   msg_envelope_t* meta) override {
                    cv::resize(frame, output, cv::Size(m_width, m_height));
                    return UdfRetCode::UDF_OK;
            };
        };
    }  // namespace udfsamples
}  // namespace eii

extern "C" {
/**
 * Create the UDF.
 *
 * @return void*
 */
void* initialize_udf(config_t* config) {
    eii::udfsamples::ResizeUdf* udf = new eii::udfsamples::ResizeUdf(config);
    return (void*) udf;
}
}  // extern "C"

