// Copyright Intel Corporation

/**
 * @file
 * @brief Fps UDF Implementation to measure the frame rate
 */

#ifndef _FPS_H
#define _FPS_H

#include <eii/udf/base_udf.h>
#include <eii/utils/logger.h>
#include <iostream>
#include <chrono>
#include <safe_lib.h>
#include <mutex>

using namespace eii::udf;

/**
* FPS UDF is used to measure total frames received every second
*/
class FpsUdf : public BaseUdf {
    private:
        // Frame counter     
        int m_frame_count;
        // Fps value
       	int m_fps;
        // Start timer
	std::chrono::time_point<std::chrono::system_clock> m_start;
        // End timer
       	std::chrono::time_point<std::chrono::system_clock> m_end;
        // MsbBus return value
	msgbus_ret_t m_ret;
        // FPS key 
	char* m_fps_key;
        // Flag for first frame
	bool m_first_frame;
        // Mutex lock
        std::mutex m_mtx;

        /**
         * Private @c FpsUdf copy constructor.
         */
        FpsUdf(const FpsUdf& src);

        /**
         * Private @c FpsUdf assignment operator.
         */
        FpsUdf& operator=(const FpsUdf& src);

    public:
	/**
         * Constructor
         *
         * @param config - Config of the Native UDF
         */
	FpsUdf(config_t* config);

	/**
         * Destructor
         */
	~FpsUdf();

	/**
         * Overridden frame processing method.
         *
         * @param frame - Frame to process
	 * @param output - Output frame
	 * @param meta - Frame metadata
         * @return UdfRetCode
         */
	UdfRetCode process(cv::Mat& frame, cv::Mat& output, msg_envelope_t* meta) override;
};
#endif //_FPS_H
