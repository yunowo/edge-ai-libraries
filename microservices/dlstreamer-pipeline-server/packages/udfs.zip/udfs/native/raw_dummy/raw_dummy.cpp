// Copyright Intel Corporation

/**
 * @file
 * @brief Dummy UDF Implementation
 */

#include <eii/udf/raw_base_udf.h>
#include <eii/utils/logger.h>
#include <iostream>

using namespace eii::udf;

namespace eii {
namespace udfsamples {

/**
 * The Raw Dummy UDF - does no processing
 */
class RawDummyUdf : public RawBaseUdf {
public:
    explicit RawDummyUdf(config_t* config) : RawBaseUdf(config) {};

    ~RawDummyUdf() {};

    UdfRetCode process(Frame* frame) override {
        LOG_INFO("Received frame with %d frames",
                frame->get_number_of_frames());
        return UdfRetCode::UDF_OK;
    };
};
}  // namespace udfsamples
}  // namespace eii

extern "C" {

/**
 * Create the UDF.
 *
 * @return void*
 */
void* initialize_udf(config_t* config) {
    eii::udfsamples::RawDummyUdf* udf = new eii::udfsamples::RawDummyUdf(config);
    return (void*) udf;
}

}  // extern "C"

