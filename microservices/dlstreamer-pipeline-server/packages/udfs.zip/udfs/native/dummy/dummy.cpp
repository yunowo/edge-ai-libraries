// Copyright Intel Corporation

/**
 * @file
 * @brief Dummy UDF Implementation
 */

#include <eii/udf/base_udf.h>
#include <eii/utils/logger.h>
#include <iostream>

using namespace eii::udf;

namespace eii {
    namespace udfsamples {

    /**
     * The Dummy UDF - does no processing
     */
        class DummyUdf : public BaseUdf {
            public:
                explicit DummyUdf(config_t* config) : BaseUdf(config) {};

                ~DummyUdf() {};

                UdfRetCode process(cv::Mat& frame, cv::Mat& output, msg_envelope_t* meta) override {
                    LOG_DEBUG("In %s method...", __PRETTY_FUNCTION__);
                    return UdfRetCode::UDF_OK;
                };
        };
    }  // namespace udfsamples
}  // namespace eii

extern "C" {

/**
 * Create the UDF.
 *
 * @return void*
 */
void* initialize_udf(config_t* config) {
    eii::udfsamples::DummyUdf* udf = new eii::udfsamples::DummyUdf(config);
    return (void*) udf;
}
}  // extern "C"

