# Copyright Intel Corporation
"""Simple Multi frame example UDF
"""

import logging
import numpy as np


class Udf:
    """Multi frame Example UDF
    """
    def __init__(self):
        """Constructor
        """
        self.log = logging.getLogger('DUMMY')
        self.log.debug(f"In {__name__}...")

    def process(self, frame, metadata):
        """[summary]

        :param frame: list of frame blob
        :type frame: list of numpy.ndarray
        :param metadata: frame's metadata
        :type metadata: str
        :return:  (should the frame be dropped, has the frame been updated,
                   new metadata for the frame if any)
        :rtype: (bool, numpy.ndarray, str)
        """
        if (isinstance(frame, list)):
            self.log.debug(f"Received list of multi frames")
        self.log.debug(f"In process() method...")

        # Simple test to return modified numpy frames
        op_frames = []
        arr = np.array([[[1, 2, 3], [4, 5, 6]], [[1, 2, 3], [4, 5, 6]]])
        arr_two = np.array([[[1, 2, 3], [4, 5, 6]], [[1, 2, 3], [4, 5, 6]]])
        op_frames.append(arr)
        op_frames.append(arr_two)

        return False, op_frames, None
