# Copyright Intel Corporation


import os
import logging
import cv2
import numpy as np
import json
import threading
from openvino.inference_engine import IECore
from distutils.util import strtobool
import time
import sys
import subprocess
import oyaml
import os

"""
Labels based on trained model used in this sample app
"""

safety_helmet = 1
safety_jacket = 2
safe = 3
violation = 4


class Udf:
    """Classifier object
    """

    def __init__(self, model_xml, model_bin, device):
        """Constructor of Classifier class

        :param classifier_config: Configuration object for the classifier
        :type classifier_config: dict
        :param input_queue: input queue for classifier
        :type input_queue: queue
        :param output_queue: output queue of classifier
        :type output_queue: queue
        :return: Classification object
        :rtype: Object
        """
        self.log = logging.getLogger('WORKER_SAFETY_DETECTION')
        self.model_xml = model_xml
        self.model_bin = model_bin
        self.device = device

        assert os.path.exists(self.model_xml), \
            'Model xml file missing: {}'.format(self.model_xml)
        assert os.path.exists(self.model_bin), \
            'Model bin file missing: {}'.format(self.model_bin)

        # Load OpenVINO model
        self.ie = IECore()
        self.neuralNet = self.ie.read_network(
            model=self.model_xml, weights=self.model_bin)

        if self.neuralNet is not None:
            self.inputBlob = next(iter(self.neuralNet.input_info))
            self.outputBlob = next(iter(self.neuralNet.outputs))
            self.neuralNet.batch_size = 1

        self.executionNet = self.ie.load_network(network=self.neuralNet,
                                                     device_name=self.
                                                     device.upper())
        self.profiling = bool(strtobool(os.environ['PROFILING_MODE']))

    # Main classification algorithm
    def process(self, frame, metadata):
        """Reads the image frame from input queue for classifier
        and classifies against the specified reference image.
        """
        proc_start = time.time()

        if self.profiling is True:
            metadata['ts_va_classify_entry'] = time.time()*1000


        defects = []
        d_info = []

        n, c, h, w = self.neuralNet.input_info[self.inputBlob].input_data.shape
        cur_request_id = 0
        labels_map = None

        inf_start = time.time()
        initial_h = frame.shape[0]
        initial_w = frame.shape[1]

        in_frame = cv2.resize(frame, (w, h))
        # Change data layout from HWC to CHW
        in_frame = in_frame.transpose((2, 0, 1))
        in_frame = in_frame.reshape((n, c, h, w))
        self.executionNet.infer(inputs={self.inputBlob: in_frame})

        inf_end = time.time()
        det_time = inf_end - inf_start
        fps = str("%.2f" % (1/det_time))
        self.log.debug("FPS after inference: {}".format(fps))

        # Parse detection results of the current request
        infer_request = self.executionNet.requests[cur_request_id]
        output_blobs = infer_request.output_blobs
        res = output_blobs[self.outputBlob].buffer
        for obj in res[0][0]:
            # obj[1] representing the category of the object detection
            # Draw only objects when probability more than specified
            # threshold represented by obj[2]

            if obj[1] == 1 and obj[2] > 0.57:
                xmin = int(obj[3] * initial_w)
                ymin = int(obj[4] * initial_h)
                xmax = int(obj[5] * initial_w)
                ymax = int(obj[6] * initial_h)
                class_id = int(obj[1])
                prob = obj[2]

                defects.append({'type': safety_helmet,
                                'tl': (xmin, ymin),
                                'br': (xmax, ymax)})

            if obj[1] == 2 and obj[2] > 0.525:
                xmin = int(obj[3] * initial_w)
                ymin = int(obj[4] * initial_h)
                xmax = int(obj[5] * initial_w)
                ymax = int(obj[6] * initial_h)
                class_id = int(obj[1])
                prob = obj[2]

                defects.append({'type': safety_jacket,
                                'tl': (xmin, ymin),
                                'br': (xmax, ymax)})

            if obj[1] == 3 and obj[2] > 0.3:
                xmin = int(obj[3] * initial_w)
                ymin = int(obj[4] * initial_h)
                xmax = int(obj[5] * initial_w)
                ymax = int(obj[6] * initial_h)
                class_id = int(obj[1])
                prob = obj[2]

                defects.append({'type': safe, 'tl': (xmin, ymin),
                                'br': (xmax, ymax)})

            if obj[1] == 4 and obj[2] > 0.35:
                xmin = int(obj[3] * initial_w)
                ymin = int(obj[4] * initial_h)
                xmax = int(obj[5] * initial_w)
                ymax = int(obj[6] * initial_h)
                class_id = int(obj[1])
                prob = obj[2]

                defects.append({'type': violation, 'tl': (xmin, ymin),
                                'br': (xmax, ymax)})

        metadata["defects"] = defects
        proc_end = time.time()
        self.log.debug("Process time: {}".format(1000*(proc_end - proc_start)))
        self.log.debug("Inference time: {}".format(1000*(inf_end - inf_start)))
        if self.profiling is True:
            metadata['ts_va_classify_exit'] = time.time()*1000
        return False, None, metadata
