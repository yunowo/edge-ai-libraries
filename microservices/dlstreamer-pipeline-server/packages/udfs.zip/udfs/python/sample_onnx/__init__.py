# Copyright Intel Corporation
"""Sample ONNX UDF Python module.
"""
