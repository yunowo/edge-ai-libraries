# Copyright Intel Corporation
"""Test UDF to verify that an exception raised in the UDFs constructor is
properly propagated in Python.
"""


class Udf:
    def __init__(self):
        """Constructor
        """
        raise RuntimeError('Constructor exception test')

    def process(self, frame, meta):
        """Change all the values in the frame to 1 and return meta-data.
        """
        return False, None, None
