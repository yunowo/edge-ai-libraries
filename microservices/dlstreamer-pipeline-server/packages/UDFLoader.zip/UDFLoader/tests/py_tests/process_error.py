# Copyright Intel Corporation
"""Test UDF to verify that an exception raised in the UDFs process() method is
properly propagated in Python.
"""


class Udf:
    def __init__(self):
        """Constructor
        """
        pass

    def process(self, frame, meta):
        """Change all the values in the frame to 1 and return meta-data.
        """
        raise RuntimeError('process() exception test')
