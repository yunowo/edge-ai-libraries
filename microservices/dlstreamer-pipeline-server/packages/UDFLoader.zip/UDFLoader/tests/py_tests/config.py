# Copyright Intel Corporation
"""Test UDF to verify correct configuration values and types are given to the
constructor.
"""


class Udf:
    def __init__(self, integer, floating, string, boolean, empty, arr, obj):
        """Constructor
        """
        assert integer == 42
        assert floating == 55.5
        assert string == "Hello, World!"
        assert boolean is True
        assert empty is None
        assert len(arr) == 2
        assert arr == ['test', True]
        assert obj['string'] == 'Hello, from object'

    def process(self, frame, meta):
        """Change all the values in the frame to 1 and return meta-data.
        """
        return False, None, None
