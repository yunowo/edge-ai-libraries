# Copyright Intel Corporation
"""Test UDF to verify modifying an actual frame.
"""
import cv2
import numpy as np


class Udf:
    def __init__(self):
        """Constructor
        """
        pass

    def process(self, frame, meta):
        """Change all the values in the frame to 1 and return meta-data.
        """
        return False, frame, None
