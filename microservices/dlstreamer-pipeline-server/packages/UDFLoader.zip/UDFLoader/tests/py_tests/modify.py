# Copyright Intel Corporation
"""Test UDF to verify that the frame and meta-data of a frame can be modified
from a Python UDF.
"""
import numpy as np


class Udf:
    def __init__(self):
        """Constructor
        """
        pass

    def process(self, frame, meta):
        """Change all the values in the frame to 1 and return meta-data.
        """
        meta['ADDED'] = 55
        if isinstance(frame, list):
            for i in range(len(frame)):
                frame[i].fill(1)
        else:
            frame.fill(1)
        return False, frame, meta
