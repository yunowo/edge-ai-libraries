# Copyright Intel Corporation
"""Test UDF to verify that a UDF can specify to drop a frame from Python.
"""


class Udf:
    def __init__(self):
        """Constructor
        """
        pass

    def process(self, frame, meta):
        """Change all the values in the frame to 1 and return meta-data.
        """
        return True, None, None
