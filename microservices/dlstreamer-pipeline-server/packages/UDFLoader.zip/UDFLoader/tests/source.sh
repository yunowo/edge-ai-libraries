#!/bin/bash
# Copyright Intel Corporation

## Simple script for setting up the PYTHONPATH for executing unit tests
export PYTHONPATH=${PYTHONPATH}:${PWD}:../../../../
