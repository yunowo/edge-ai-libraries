// Copyright Intel Corporation

/**
 * @brief Example native UDF.
 */

#include <eii/udf/base_udf.h>
#include <eii/utils/logger.h>

namespace eii {
namespace udf {

/**
 * The do nothing UDF
 */
class NativeExampleUdf : public BaseUdf {
public:
    NativeExampleUdf(config_t* config) : BaseUdf(config) {};

    ~NativeExampleUdf() {};

    UdfRetCode process(cv::Mat& frame, cv::Mat& output, msg_envelope_t* meta) override {
        LOG_INFO_0("NativeExampleUdf::process()");
        //cv::resize(frame, output, cv::Size(), 0.50, 0.50);
		return UdfRetCode::UDF_OK;
    };
};

} // udf
} // eii

extern "C" {

/**
 * Create the UDF.
 *
 * @return void*
 */
void* initialize_udf(config_t* config) {
    eii::udf::NativeExampleUdf* udf = new eii::udf::NativeExampleUdf(config);
	return (void*) udf;
}

} // extern "C"
