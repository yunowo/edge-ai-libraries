# Copyright Intel Corporation
"""Simple example UDF.
"""
import cv2


class Udf:
    """Example UDF
    """
    def __init__(self, param1, param2):
        """Constructor
        """
        print(f'[PYTHON::INFO] param1={param1}, param2={param2}')

    def process(self, frame, meta):
        """Process frame.
        """
        frame = cv2.resize(frame[0], (960, 600))
        return False, frame, None
