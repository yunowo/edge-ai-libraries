// Copyright Intel Corporation

/**
 * @brief Implementation of the @c UdfLoader class
 */

#include "eii/udf/loader.h"
#include <eii/utils/logger.h>
#include "eii/udf/python_udf_handle.h"
#include "eii/udf/native_udf_handle.h"
#include "eii/udf/raw_udf_handle.h"
#include <safe_lib.h>

#include "cython/udf.h"

using namespace eii::udf;

// Globals for Python interpreter
// PyInterpreterState* g_state;
PyThreadState* g_th_state = NULL;

// Static boolean to keep track of whether or not the UDF Loader class
// initalized the Python interpreter. If it did, then it is responsible for
// finalizing it. However, if it did not, then it does not need to finalize the
// interpreter.
static bool g_finalize_python = false;


UdfLoader::UdfLoader() {}

UdfLoader::~UdfLoader() {
    LOG_DEBUG_0("Destroying UDF Loader");
    if (g_th_state != NULL) {
        PyEval_RestoreThread(g_th_state);
        if (g_finalize_python)
            Py_FinalizeEx();
        else
            PyEval_ReleaseThread(g_th_state);
        g_th_state = NULL;
    }
}

UdfHandle* UdfLoader::load(
        std::string name, config_t* config, int max_workers) {
    // TODO remove strcompare and convert to an enum?
    config_value_t* type = config_get(config, "type");

    if (type == NULL) {
        LOG_ERROR_0("Error retreiving UDF type");
        return NULL;
    }

    if (type->type != CVT_STRING) {
        LOG_ERROR_0("UDF type should be a string!");
        return NULL;
    }

    UdfHandle* udf = NULL;

    int ind_body_string_python = 0;
    int ind_body_string_native = 0;
    int ind_body_string_raw_native = 0;
    strcmp_s(type->body.string, strlen(type->body.string), "python", &ind_body_string_python);
    strcmp_s(type->body.string, strlen(type->body.string), "native", &ind_body_string_native);
    strcmp_s(type->body.string, strlen(type->body.string), "raw_native", &ind_body_string_raw_native);
    if (ind_body_string_python == 0) {
        if (!Py_IsInitialized()) {
            LOG_DEBUG_0("Initializing python");
            PyImport_AppendInittab("udf", PyInit_udf);
            Py_Initialize();
            // Set the finalize flag, indicating that the UDF Loader should
            // finalize Python when it is destroyed.
            g_finalize_python = true;
            PyEval_InitThreads();
            g_th_state = PyThreadState_Get();
        } else {
            // Attempt to load Python UDF
            LOG_INFO_0("Python is already intiailized");
            if (g_th_state == NULL) {
                LOG_DEBUG_0("Getting Python thread state");
                PyGILState_STATE gstate = PyGILState_Ensure();
                g_th_state = PyThreadState_Get();
                PyGILState_Release(gstate);
            }
            PyEval_RestoreThread(g_th_state);
        }

        udf = new PythonUdfHandle(name, max_workers);
        if (!udf->initialize(config)) {
            delete udf;
            udf = NULL;
        }

        PyEval_SaveThread();
        LOG_DEBUG("Has GIL: %d", PyGILState_Check());
    } else if (ind_body_string_native == 0) {
        // Attempt to load native UDF
        udf = new NativeUdfHandle(name, max_workers);
        if (!udf->initialize(config)) {
            delete udf;
            udf = NULL;
        }
    } else if (ind_body_string_raw_native == 0) {
        // Attempt to load native UDF
        udf = new RawUdfHandle(name, max_workers);
        if (!udf->initialize(config)) {
            delete udf;
            udf = NULL;
        }
    }

    config_value_destroy(type);

    return udf;
}
