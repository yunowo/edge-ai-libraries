// Copyright Intel Corporation

/**
 * @brief @c UdfHandle implementation
 */

#include "eii/udf/udf_handle.h"
#include "eii/utils/logger.h"

using namespace eii::udf;

UdfHandle::UdfHandle(std::string name, int max_workers) :
    m_name(name), m_initialized(false), m_max_workers(max_workers),
    m_config(NULL)
{}

UdfHandle::~UdfHandle() {
    LOG_DEBUG_0("Base UdfHandle destructor");

    if (m_initialized.load()) {
        config_destroy(m_config);
    }

    // TODO: Clean up thread pool
}

bool UdfHandle::initialize(config_t* config) {
    // Verify the UDF handle has not already been initialized
    if (m_initialized.load()) {
        LOG_WARN_0("Initialize called twice for a given UDF handle");
        return true;
    }

    // Initialize internal state variables
    m_initialized.store(true);
    m_config = config;

    return true;
}

std::string UdfHandle::get_name() {
    return m_name;
}

std::string UdfHandle::get_prof_entry_key() {
    return m_prof_entry_key;
}

std::string UdfHandle::get_prof_exit_key() {
    return m_prof_exit_key;
}

void UdfHandle::set_prof_entry_key(std::string value) {
    m_prof_entry_key = value;
}

void UdfHandle::set_prof_exit_key(std::string value) {
    m_prof_exit_key = value;
}
