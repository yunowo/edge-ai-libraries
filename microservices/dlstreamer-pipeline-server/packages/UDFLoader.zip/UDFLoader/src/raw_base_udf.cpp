// Copyright Intel Corporation

/**
 * @brief Implementation of @c RawBaseUdf class
 */

#include <eii/utils/logger.h>
#include "eii/udf/raw_base_udf.h"

using namespace eii::udf;

RawBaseUdf::RawBaseUdf(config_t* config) :
    m_config(config)
{}

RawBaseUdf::~RawBaseUdf() {
    // NOTE: The m_config value is not freed here because this should always
    // be internally wrapped by a @c UdfHandle which manages the memory for
    // the configuration object.
}
