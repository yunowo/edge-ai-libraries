// Copyright Intel Corporation

/**
 * @brief Implementation of @c BaseUdf class
 */

#include <eii/utils/logger.h>
#include "eii/udf/base_udf.h"

using namespace eii::udf;

BaseUdf::BaseUdf(config_t* config) :
    m_config(config)
{}

BaseUdf::~BaseUdf() {
    // NOTE: The m_config value is not freed here because this should always
    // be internally wrapped by a @c UdfHandle which manages the memory for
    // the configuration object.
}
