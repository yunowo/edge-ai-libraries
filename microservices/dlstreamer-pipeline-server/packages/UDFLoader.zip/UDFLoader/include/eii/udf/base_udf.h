// Copyright Intel Corporation

/**
 * @file
 * @brief Base UDF class for native UDF implementations.
 */

#ifndef _EII_UDF_BASE_UDF_H
#define _EII_UDF_BASE_UDF_H

#include <atomic>
#include <opencv2/opencv.hpp>
#include <eii/msgbus/msg_envelope.h>
#include <eii/utils/config.h>
#include "eii/udf/udfretcodes.h"

namespace eii {
namespace udf {

class BaseUdf {
protected:
    // UDF configuration
    //
    // NOTE: The memory for this configuration is managed by the
    // @c UdfHandle class and does not need to be freed in the UDF object.
    config_t* m_config;

public:
    /**
     * Constructor
     */
    BaseUdf(config_t* config);

    /**
     * Destructor
     */
    virtual ~BaseUdf();

    /**
     * Process the given frame.
     *
     * @param frame - @c cv::Mat frame object
     * @param meta  - @c msg_envelope_t for the meta data to add to the frame
     *                after the UDF executes over it.
     * @return @c UdfRetCode
     */
    virtual UdfRetCode process(cv::Mat& frame, cv::Mat& output, msg_envelope_t* meta) = 0;
};

} // udf
} // eii

#endif // _EII_UDF_BASE_UDF_H
