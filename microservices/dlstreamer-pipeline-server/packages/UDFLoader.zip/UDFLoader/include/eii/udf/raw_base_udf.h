// Copyright Intel Corporation

/**
 * @file
 * @brief Base UDF class for native UDF implementations.
 */

#ifndef _EII_UDF_RAW_BASE_UDF_H
#define _EII_UDF_RAW_BASE_UDF_H

#include <atomic>
#include <opencv2/opencv.hpp>
#include <eii/msgbus/msg_envelope.h>
#include <eii/utils/config.h>
#include "eii/udf/udfretcodes.h"
#include "eii/udf/frame.h"

namespace eii {
namespace udf {

class RawBaseUdf {
protected:
    // UDF configuration
    //
    // NOTE: The memory for this configuration is managed by the
    // @c UdfHandle class and does not need to be freed in the UDF object.
    config_t* m_config;

public:
    /**
     * Constructor
     */
    RawBaseUdf(config_t* config);

    /**
     * Destructor
     */
    virtual ~RawBaseUdf();

    /**
     * Process the given frame.
     *
     * @param frame - @c void* frame object
     * @param meta  - @c msg_envelope_t for the meta data to add to the frame
     *                after the UDF executes over it.
     * @return @c UdfRetCode
     */
    virtual UdfRetCode process(Frame* frame) = 0;
};

} // udf
} // eii

#endif // _EII_UDF_RAW_BASE_UDF_H
