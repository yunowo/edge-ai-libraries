// Copyright Intel Corporation

/**
 * @file
 * @brief UDF loader library entry point. Provides the object for loading UDFs
 *      into the application.
 */

#ifndef _EII_UDF_LOADER_H
#define _EII_UDF_LOADER_H

#include <eii/utils/config.h>
#include "eii/udf/udf_handle.h"

namespace eii {
namespace udf {

/**
 * UDF loader object.
 */
class UdfLoader {
public:
    /**
     * Constructor
     */
    UdfLoader();

    /**
     * Destructor
     */
    ~UdfLoader();

    /**
     * Load a UDF from a library either in the `LD_LIBRARY_PATH` or the
     * `PYTHONPATH`.
     *
     * For native UDF implmentations, the `load()` method will search
     * in the LD_LIBRARY_PATH environmental variable directories. The
     * library names are expected to follow the naming convention:
     * `lib<name>.so`.
     *
     * @param name        - Name of the UDF to load
     * @param config      - Configuration for the UDF
     * @param max_workers - Maximum number of worker threads for executing UDFs
     * @return @c UdfHandle, NULL if not found
     */
    UdfHandle* load(std::string name, config_t* config, int max_workers);
};

} // udf
} // eii

#endif // _EII_UDF_LOADER_H
