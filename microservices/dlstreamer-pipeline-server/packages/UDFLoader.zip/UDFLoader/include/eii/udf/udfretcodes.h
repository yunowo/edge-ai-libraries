// Copyright Intel Corporation

/**
 * @file
 * @brief Return values for UDFs.
 */

#ifndef _EII_UDF_UDF_RET_CODES_H
#define _EII_UDF_UDF_RET_CODES_H

namespace eii {
namespace udf {

enum UdfRetCode {
    // Specifies that the UDF has processed and all is good, no action needed
    // by the caller
    UDF_OK = 0,

    // Specifies that the frame given to the process() method should dropped
    UDF_DROP_FRAME = 1,

    // Return value used specifically for Python UDFs
    UDF_FRAME_MODIFIED = 2,

    // The UDF encountered an error
    UDF_ERROR = 255,
};

} // udf
} // eii

#endif // _EII_UDF_UDF_RET_CODES_H
