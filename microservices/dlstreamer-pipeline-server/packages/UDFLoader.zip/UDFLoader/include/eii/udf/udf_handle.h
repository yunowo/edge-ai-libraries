// Copyright Intel Corporation

/**
 * @file
 * @brief Handle for a UDF to be called via the loader.
 */

#ifndef _EII_UDF_UDF_HANDLE_H
#define _EII_UDF_UDF_HANDLE_H

#include <atomic>
#include <string>
#include <eii/utils/config.h>
#include "eii/udf/frame.h"
#include "eii/udf/udfretcodes.h"

namespace eii {
namespace udf {

/**
 * UDF handle class.
 */
class UdfHandle {
private:
    // Name of the UDF
    std::string m_name;

    // Flag for if the UDF is initialized
    std::atomic<bool> m_initialized;

    // Max number of worker threads for executing the UDF
    int m_max_workers;

    // Profiling start timestamp key
    std::string m_prof_entry_key;

    // Profiling end timestamp key
    std::string m_prof_exit_key;

protected:
    // UDF Configuration
    config_t* m_config;

    // TODO: Add thread pool definition

public:
    /**
     * Constructor
     *
     * @param name        - Name of the UDF
     * @param max_workers - Max number of worker threads for the UDF
     */
    UdfHandle(std::string name, int max_workers);

    /**
     * Destructor
     */
    virtual ~UdfHandle();

    /**
     * Initialize the UDF.
     *
     * @param config - UDF configuration
     * @return bool
     */
    virtual bool initialize(config_t* config);

    /**
     * Return whether or not the UDF has been initialized.
     * @return bool
     */
    bool is_initialized();

    /**
     * Process the given frame.
     *
     * The return values have the following meanings for this method:
     *
     * - @c UdfRetCode::UDF_OK - Frame processed, no action required by caller
     * - @c UdfRetCode::UDF_DROP_FRAME - The caller of the UDF should not
     *      continue processing the frame given to the UDF
     * - @c UdfRetCode::UDF_MODIFIED_FRAMe - The caller should continue with
     *      the modified version of the frame
     *
     * @param frame - Frame to process
     * @return @c UdfRetCode
     */
    virtual UdfRetCode process(Frame* frame, msg_envelope_t* gst_meta) = 0;


    /**
     * Get the name of the UDF.
     *
     * @return Name of the UDF
     */
    std::string get_name();

    /**
     * Get profiling start timestamp key
     *
     * @return profiling start timestamp key
     */
    std::string get_prof_entry_key();

    /**
     * Get profiling end timestamp key
     *
     * @return profiling end timestamp key
     */
    std::string get_prof_exit_key();

    /**
     * Set profiling start timestamp key
     *
     * @param value - Value to be set
     */
    void set_prof_entry_key(std::string value);

    /**
     * Set profiling end timestamp key
     *
     * @param value - Value to be set
     */
    void set_prof_exit_key(std::string value);
};

} // udf
} // eii

#endif // _EII_UDF_UDF_HANDLE_H
