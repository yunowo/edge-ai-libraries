// Copyright Intel Corporation

/**
 * @file
 * @brief C++ UDF
 */

#ifndef _EII_UDF_NATIVE_UDF_H
#define _EII_UDF_NATIVE_UDF_H


#include "eii/udf/udf_handle.h"
#include "eii/udf/base_udf.h"

namespace eii {
namespace udf {

class NativeUdfHandle : public UdfHandle {
private:
    //References needed after init
    void* m_lib_handle;
    void* (*m_func_initialize_udf)(config_t*);
    BaseUdf* m_udf;

    /**
     * Private @c NativeUdfHandle copy constructor.
     */
    NativeUdfHandle(const NativeUdfHandle& src);

    /**
     * Private @c NativeUdfHandle assignment operator.
     *
     */
    NativeUdfHandle& operator=(const NativeUdfHandle& src);

public:
    /**
     * Constructor
     *
     * @param name - Name of the Native UDF
     */
    NativeUdfHandle(std::string name, int max_workers);

    /**
     * Destructor
     */
    ~NativeUdfHandle();

    /**
     * Overridden initialization method
     *
     * @param config - UDF configuration
     * @return bool
     */
    bool initialize(config_t* config) override;

    /**
     * Overridden frame processing method.
     *
     * @param frame - Frame to process
     * @return UdfRetCode
     */
    UdfRetCode process(Frame* frame, msg_envelope_t* gst_meta) override;

};

} // eii
} // udf

#endif // _EII_UDF_NATIVE_UDF_H
