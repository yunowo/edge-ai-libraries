// Copyright Intel Corporation

/**
 * @file
 * @brief Python UDF
 */

#ifndef _EII_UDF_PYTHON_UDF_H
#define _EII_UDF_PYTHON_UDF_H

#include <Python.h>
#include "eii/udf/udf_handle.h"

namespace eii {
namespace udf {

/**
 * Return value for a Python UDF.
 *
 * \note This is only used between the @c PythonUdfHandle and the Cython shim
 */
typedef struct {
    // UDF return code (i.e. UDF_OK, UDF_ERROR, etc.)
    UdfRetCode return_code;
    // Updated frame (if needed)
    PyObject* updated_frame;
} PythonUdfRet;

/**
 * Python UDF wrapper object
 */
class PythonUdfHandle : public UdfHandle {
private:
    // Reference to UDF Python object
    PyObject* m_udf_obj;

    // Reference to the process() method on the Python object
    PyObject* m_udf_func;

public:
    /**
     * Constructor
     *
     * @param name - Name of the Python UDF
     */
    PythonUdfHandle(std::string name, int max_workers);

    /**
     * Destructor
     */
    ~PythonUdfHandle();

    /**
     * Overridden initialization method
     *
     * @param config - UDF configuration
     * @return bool
     */
    bool initialize(config_t* config) override;

    /**
     * Overridden frame processing method.
     *
     * @param frame - Frame to process
     * @return UdfRetCode
     */
    UdfRetCode process(Frame* frame, msg_envelope_t* gst_meta) override;
};

} // udf
} // eii

#endif // _EII_UDF_PYTHON_UDF_H
