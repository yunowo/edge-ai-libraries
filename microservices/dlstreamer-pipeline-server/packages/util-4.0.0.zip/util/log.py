# Copyright Intel Corporation

import os
import logging
import logging.handlers
import sys

LOG_LEVELS = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'ERROR': logging.ERROR,
    'WARN': logging.WARN
}


def configure_logging(log_level, module_name, dev_mode):
    """Configure logging to log to stdout.

    The log string will be formatted as follows:
        '%(asctime)s : %(levelname)s : %(name)s : [%(filename)s] :
            '%(funcName)s : in line : [%(lineno)d] : %(message)s'

    This function should only ever be called once in a the Python runtime.

    :param log_level: Logging level to use, must be one of the following:
           DEBUG, INFO, ERROR or WARN
    :type log_level: str
    :param module_name: Module running logging
    :type module_name: str
    :raises Exception: If the given log level is unknown, or if max_bytes
                       and file_count are both 0, or if the log file directory
                       does not exist.
    :return: Logging object
    :rtype: Object
    """
    if log_level not in LOG_LEVELS:
        raise Exception('Unknown log level: {}'.format(log_level))

    if dev_mode:
        fmt_str = ('%(asctime)s : %(levelname)s  : {} : %(name)s : ' +
                   '[%(filename)s] :' .format("Insecure Mode") +
                   '%(funcName)s : in line : [%(lineno)d] : %(message)s')
    else:
        fmt_str = ('%(asctime)s : %(levelname)s : %(name)s : ' +
                   '[%(filename)s] :' +
                   '%(funcName)s : in line : [%(lineno)d] : %(message)s')

    log_lvl = LOG_LEVELS[log_level]
    logging.basicConfig(format=fmt_str, level=log_lvl)
    logger = logging.getLogger(module_name)
    logger.setLevel(log_lvl)

    # Do basic configuration of logging (just for stdout config)
    logging.basicConfig(format=fmt_str, level=log_lvl)

    logger = logging.getLogger()
    logger.setLevel(log_lvl)
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter(fmt_str)
    handler.setFormatter(formatter)

    # Removing the default handler added by getLogger to avoid duplicate logs
    if(logger.hasHandlers()):
        logger.handlers.clear()
    logger.addHandler(handler)

    return logger
