"""
Copyright Intel Corporation
"""


class DAException(Exception):
    pass
