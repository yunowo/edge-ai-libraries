// Copyright Intel Corporation

/**
 * @brief Unit tests for logger
 */

#include <gtest/gtest.h>
#include "eii/utils/logger.h"

TEST(logger_tests, set_log_lvl) {
    set_log_level(LOG_LVL_INFO);
    ASSERT_EQ(get_log_level(), LOG_LVL_INFO);
}
