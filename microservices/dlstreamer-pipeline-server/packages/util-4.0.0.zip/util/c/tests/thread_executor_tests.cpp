// Copyright Intel Corporation

/**
 * @brief ThreadExecutor unit tests
 */

#include "eii/utils/thread_executor.hpp"
#include "eii/utils/logger.h"
#include <gtest/gtest.h>
#include <stdlib.h>
#include <atomic>
#include <chrono>
#include <sstream>
#include <string>
#include <safe_lib.h>


void test_run(int tid, std::atomic<bool>& m_stop, void* vargp) {
    LOG_INFO("In thread: %d", tid);
    while (!m_stop.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(250));
    }
}

void test_run_err(int tid, std::atomic<bool>& m_stop, void* vargp) {
    LOG_INFO("In thread: %d", tid);
    throw "test run error - this is meant to happen";
}

TEST(th_exec_tests, basic_run) {
    // Initialize ThreadExecutor
    eii::utils::ThreadExecutor* executor = new eii::utils::ThreadExecutor(
            4, test_run, NULL);

    // Sleep for 3 seconds
    std::this_thread::sleep_for(std::chrono::seconds(3));

    // Delete memory to make sure threads stop
    delete executor;
}

TEST(th_exec_tests, error_run) {
    // Initialize ThreadExecutor
    eii::utils::ThreadExecutor* executor = new eii::utils::ThreadExecutor(
            4, test_run_err, NULL);

    // Sleep for 3 seconds
    std::this_thread::sleep_for(std::chrono::seconds(3));

    // Delete memory to make sure threads stop
    delete executor;
}

/**
 * Overridden GTest main method
 */
GTEST_API_ int main(int argc, char** argv) {
    // Parse out gTest command line parameters
    ::testing::InitGoogleTest(&argc, argv);

    // Check if log level provided
    if (argc == 3) {
        int ind_argv = 0;
        strcmp_s(argv[1], strlen(argv[1]), "--log-level", &ind_argv);
        if (ind_argv == 0) {
            // LOG_INFO_0("Running msgbus tests over TCP");
            char* log_level = argv[2];
            int ind_info = 0;
            int ind_debug = 0;
            int ind_error = 0;
            int ind_warn = 0;
            strcmp_s(log_level, strlen(log_level), "INFO", &ind_info);
            strcmp_s(log_level, strlen(log_level), "DEBUG", &ind_debug);
            strcmp_s(log_level, strlen(log_level), "ERROR", &ind_error);
            strcmp_s(log_level, strlen(log_level), "WARN", &ind_warn);
            if (ind_info == 0) {
                set_log_level(LOG_LVL_INFO);
            } else if (ind_debug == 0) {
                set_log_level(LOG_LVL_DEBUG);
            } else if (ind_error == 0) {
                set_log_level(LOG_LVL_ERROR);
            } else if (ind_warn == 0) {
                set_log_level(LOG_LVL_WARN);
            } else {
                LOG_ERROR("Unknown log level: %s", log_level);
                return -1;
            }
        } else {
            LOG_ERROR("Unknown parameter: %s", argv[1]);
            return -1;
        }
    } else if (argc == 2) {
        LOG_ERROR_0("Incorrect number of arguments");
        return -1;
    }

    // Run the tests
    return RUN_ALL_TESTS();
}
