// Copyright Intel Corporation

/**
 * @brief Simple test library to load
 */

#include <stdio.h>

void test_function() {
    printf("Hello from test_function()\n");
}
