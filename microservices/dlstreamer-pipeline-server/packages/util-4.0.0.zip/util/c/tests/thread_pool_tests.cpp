// Copyright Intel Corporation

/**
 * @brief EII thread safe queue unit tests
 */

#include <stdlib.h>
#include <thread>
#include <gtest/gtest.h>
#include "eii/utils/thread_pool.h"

using namespace eii::utils;

#define FAIL_NULL(val, msg) { \
    if(val == NULL) FAIL() << msg; \
}

void simple_run(void* vargs) {
    int* num = (int*) vargs;
    printf("-- Simple fn: %d\n", *num);
}

void sleep_run(void* vargs) {
    int* num = (int*) vargs;
    printf("-- Sleep fn: %d\n", *num);
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
}

TEST(th_pool_tests, simple) {
    auto duration = std::chrono::milliseconds(500);
    int val = 42;
    ThreadPool tp(1, -1);

    // Submit the job
    JobHandle* handle = tp.submit(simple_run, (void*) &val, NULL);
    FAIL_NULL(handle, "Handle is null");

    // The wait really should return immediately
    ASSERT_EQ(handle->wait_for(duration), true);

    // Clean up
    delete handle;
    tp.stop();
}

TEST(th_pool_tests, multi_jobs) {
    auto duration = std::chrono::milliseconds(500);
    ThreadPool tp(2, -1);

    int val = 0;
    JobHandle* handle = tp.submit(sleep_run, (void*) &val, NULL);
    FAIL_NULL(handle, "Handle is null");

    int val2 = 1;
    JobHandle* handle2 = tp.submit(sleep_run, (void*) &val2, NULL);
    FAIL_NULL(handle2, "Handle2 is null");

    // The wait really should return immediately
    handle->wait();
    handle2->wait();

    // Clean up
    delete handle;
    delete handle2;
    tp.stop();
}

TEST(th_pool_tests, queue_full) {
    ThreadPool tp(1, 1);

    int val = 0;
    JobHandle* handle = tp.submit(sleep_run, (void*) &val, NULL);
    FAIL_NULL(handle, "Handle is null");

    int val2 = 1;
    JobHandle* handle2 = tp.submit(sleep_run, (void*) &val2, NULL);
    FAIL_NULL(handle2, "Handle2 is null");

    handle2->wait();

    delete handle;
    delete handle2;
    tp.stop();
}
