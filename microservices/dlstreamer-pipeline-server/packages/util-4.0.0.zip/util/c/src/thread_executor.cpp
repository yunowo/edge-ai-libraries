// Copyright Intel Corporation

/**
 * @brief Thread Executor Utility implementation
 */

#include "eii/utils/thread_executor.hpp"
#include "eii/utils/logger.h"

namespace eii {
namespace utils {

ThreadExecutor::ThreadExecutor(
        int num_threads, ExecutorRunMethod fn, void* varg) :
    m_stop(false) {
    // Launch thread executor threads
    for (int i = 0; i < num_threads; i++) {
        LOG_DEBUG("Starting thread %d", i);
        std::thread* th = new std::thread(
                &ThreadExecutor::run_wrapper, this, i, fn, varg);
        m_threads.push_back(th);
    }
}

ThreadExecutor::~ThreadExecutor() {
    LOG_DEBUG_0("ThreadExecutor destructor");
    this->stop();
}

void ThreadExecutor::stop() {
    // Do not allow for duplicate stops
    if (m_stop.load()) { return; }

    LOG_DEBUG_0("Stopping thread executor threads");

    // Flag all threads to stop
    m_stop.store(true);

    // Wait for threads to join, and clean up memory
    size_t num_threads = m_threads.size();
    for (int i = 0; i < num_threads; i++) {
        LOG_DEBUG("Waiting for thread %d to join", i);
        std::thread* th = m_threads.at(i);
        th->join();
        LOG_DEBUG("Thread %d joined, deleting thread", i);
        delete th;
    }
}

void ThreadExecutor::run_wrapper(
        int tid, ExecutorRunMethod fn, void* varg) {
    LOG_DEBUG("Thread %d started", tid);

    try {
        // Call the user provided function pointer
        fn(tid, m_stop, varg);
    } catch (const char* ex) {
        LOG_ERROR("[tid: %d] Thread Error: %s", tid, ex);
    }

    LOG_DEBUG("Thread %d stopped", tid);
}

}  // namespace utils
}  // namespace eii
