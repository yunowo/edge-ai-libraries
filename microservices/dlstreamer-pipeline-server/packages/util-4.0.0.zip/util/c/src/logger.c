// Copyright Intel Corporation

/**
 * @brief EII logger implementation
 */

#include "eii/utils/logger.h"

// Global log level value
static log_lvl_t g_log_level = LOG_LVL_ERROR;

void set_log_level(log_lvl_t log_level) {
    g_log_level = log_level;
}

log_lvl_t get_log_level() {
    return g_log_level;
}
