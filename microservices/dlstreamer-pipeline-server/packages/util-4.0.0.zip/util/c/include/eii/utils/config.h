// Copyright Intel Corporation

/**
 * @file
 * @brief EII configuration interface
 */

#ifndef _EII_CONFIG_IFACE_H
#define _EII_CONFIG_IFACE_H

#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Valid configuration value types
 */
typedef enum {
    CVT_INTEGER  = 0,
    CVT_FLOATING = 1,
    CVT_STRING   = 2,
    CVT_BOOLEAN  = 3,
    CVT_OBJECT   = 4,
    CVT_ARRAY    = 5,
    CVT_NONE     = 6,
} config_value_type_t;

// Forward declaration of config_value_t struct
typedef struct _config_value config_value_t;

/**
 * Config value object representation. Includes method for freeing the object
 * when the caller that obtained the object is finished with it.
 */
typedef struct {
    void* object;
    config_value_t* (*get)(const void* obj, const char* key);
    void (*free)(void* object);
} config_value_object_t;

/**
 * Config value array representation. Includes methods for getting elements
 * at a given index and for freeing the array.
 */
typedef struct {
    void* array;
    size_t length;
    config_value_t* (*get)(const void* array, int idx);
    void (*free)(void* array);
} config_value_array_t;

/**
 * Structure representing a configuration value.
 */
typedef struct _config_value {
    config_value_type_t type;

    union {
        int64_t      integer;
        double       floating;
        char*        string;
        bool         boolean;
        config_value_object_t* object;
        config_value_array_t*  array;
    } body;
} config_value_t;

/**
 * Configuration object
 */
typedef struct config_t config_t;

/**
 * Configuration object
 */
struct config_t {
    void* cfg;
    void (*free)(void*);
    config_value_t* (*get_config_value)(const void*,const char*);
    bool (*set_config_value)(config_t*, const char*, config_value_t*);
};

/**
 * Create a new configuration object.
 *
 * @param cfg              - Configuration context
 * @param free_fn          - Method to free the configuration context
 * @param get_config_value - Method to retrieve a key from the configuration
 * @return config_t, or NULL if an error occurs
 */
config_t* config_new(
        void* cfg, void (*free_fn)(void*),
        config_value_t* (*get_config_value)(const void*,const char*),
        bool (*set_config_value)(config_t*, const char*, config_value_t*));

/**
 * Get value from configuration object.
 *
 * \note Returns NULL if the value cannot be found in the configuration object.
 *
 * @param config - Configuration object pointer
 * @param key    - Key for the configuration value
 * @return @c config_value_t
 */
config_value_t* config_get(const config_t* config, const char* key);

/**
 * Set value for configuration object.
 *
 * \note Returns true if the value is set, false otherwise.
 *
 * @param config - Configuration object pointer
 * @param key    - Key for the configuration value
 * @param item   - Config to be set
 * @return bool
 */
bool config_set(config_t* config, const char* key, config_value_t* item);

/**
 * Destroy the configuration object.
 *
 * @param config - Configuration to destroy
 */
void config_destroy(config_t* config);

/**
 * Retreive a configuration value from a configuration value object.
 *
 * \note The obj parameter must be a @c CVT_OBJECT type, NULL will be returned
 *       if it is not.
 *
 * @param obj    - Configuration value object
 * @param key    - Key to retrieve from the configuration object
 * @return config_value_t
 */
config_value_t* config_value_object_get(
        const config_value_t* obj, const char* key);

/**
 * Retreive a configuration value from a configuration array.
 *
 * \note The arr parameter mustb be of type @c CVT_ARRAY, otherwise NULL will
 *       be returned.
 *
 * @param arr    - Array configuration value
 * @param idx    - Index in the array to retrieve
 * @return config_value_t*
 */
config_value_t* config_value_array_get(const config_value_t* arr, int idx);

/**
 * Get the length of a configuration array.
 *
 * @param arr - Array configuration value
 * @return int
 */
size_t config_value_array_len(const config_value_t* arr);

/**
 * Helper function to create a new config_value_t pointer to the given integer
 * value.
 *
 * @param value - Integer value
 * @return config_value_t*
 */
config_value_t* config_value_new_integer(int64_t value);

/**
 * Helper to create a new config_value_t pointer to the given double value.
 *
 * @param value - Floating point value
 * @return config_value_t*
 */
config_value_t* config_value_new_floating(double value);

/**
 * Helper function to create a new config_value_t pointer to the given string
 * value.
 *
 * @param value - String value
 * @return config_value_t*
 */
config_value_t* config_value_new_string(const char* value);

/**
 * Helper function to create a new config_value_t pointer to the given boolean
 * value.
 *
 * @param value - Boolean value
 * @return config_value_t*
 */
config_value_t* config_value_new_boolean(bool value);

/**
 * Helper function to create a new config_value_t pointer to the given
 * configuration object value.
 *
 * @param value    - Object value
 * @param free_fn  - Free method for the object value
 * @return config_value_t*
 */
config_value_t* config_value_new_object(
        void* value, config_value_t* (*get)(const void*,const char*),
        void (*free_fn)(void*));

/**
 * Helper function to create a new config_value_t pointer to the given array
 * value.
 *
 * @param array   - Pointer to array context
 * @param length  - Array length
 * @param get     - Get method for getting an element in the array
 * @param free_fn - Function to free the array object
 * @return config_value_t*
 */
config_value_t* config_value_new_array(
        void* array, size_t length, config_value_t* (*get)(const void*,int),
        void (*free_fn)(void*));

/**
 * Helper function to create a new config_value_t pointer to an empty
 * configuration value.
 *
 * @return config_value_t*
 */
config_value_t* config_value_new_none();

/**
 * Destroy a configuration value.
 *
 * @param value - Configuration value to destroy
 */
void config_value_destroy(config_value_t* value);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // _EII_CONFIG_IFACE_H
