#!/bin/bash

# Copyright Intel Corporation

export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${PWD}
