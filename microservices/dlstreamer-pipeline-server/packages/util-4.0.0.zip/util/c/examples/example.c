// Copyright Intel Corporation

/**
 * @brief Simple example library to load
 */

#include <stdio.h>

void example_function() {
    printf("Hello from example_function()\n");
}
