// Copyright Intel Corporation

/**
 * @brief dynlibload simple loading example
 */

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include "eii/dynlibload/dynlibload.h"

#define LIBRARY_NAME "libexample.so"
#define FUNC_NAME    "example_function"

int main(int argc, char** argv) {
    dynlib_ctx_t* lib = NULL;

    // Dynamically load the given library
    int ret = dynlib_new(LIBRARY_NAME, &lib);
    if(ret != DYNLOAD_SUCCESS) {
       printf("ERROR: %s\n", dynlib_strerror(ret));
       return -1;
    }

    // Load symbol for the function in the library
    void (*func)() = dynlib_load_sym(lib, FUNC_NAME);
    if(func == NULL) {
        printf("ERROR: %s\n", dynlib_strerror(errno));
        dynlib_destroy(lib);
        return -1;
    }

    // Call the loaded method
    func();

    // Clean up
    dynlib_destroy(lib);

    return 0;
}
