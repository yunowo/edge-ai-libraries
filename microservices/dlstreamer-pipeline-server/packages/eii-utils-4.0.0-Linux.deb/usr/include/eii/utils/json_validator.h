// Copyright Intel Corporation

/**
 * @file
 * @brief Utility function for validating a JSON file
 */

#ifndef _EII_UTILS_JSON_VALID_H
#define _EII_UTILS_JSON_VALID_H

namespace eii {
namespace utils {

/**
 * Validate that the json data adheres to the given schema.
 *
 * @param schema     - Raw bytes of the JSON schema
 * @param json_bytes - Raw bytes of the JSON payload
 * @return True if valid, otherwise false
 */
bool validate_json_buffer_buffer(const char* schema, const char* json_bytes);

/**
 * Validate that the json data adheres to the given schema contained in the
 * file pointed to by the schema_filename parameter.
 *
 * @param schema_filename - JSON schema file to read
 * @param json_bytes      - Raw bytes of the JSON payload
 * @return True if valid, otherwise false
 */
bool validate_json_file_buffer(
        const char* schema_filename, const char* json_bytes);

/**
 * Validate that the json data in the JSON file adheres to the given schema
 * contained in the file pointed to by the schema_filename parameter.
 *
 * @param schema_filename - JSON schema file to read
 * @param json_file       - JSON payload file to validate against the schema
 * @return True if valid, otherwise false
 */
bool validate_json_file_file(
        const char* schema_filename, const char* json_file);

}  // utils
}  // eii

#endif // _EII_UTILS_JSON_VALID_H
