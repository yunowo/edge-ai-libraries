// Copyright Intel Corporation

/**
 * @file
 * @brief Simple C macro utility for timing the execution time of a block of
 *        code.
 */

#ifndef _EII_UTILS_TIMEIT_H
#define _EII_UTILS_TIMEIT_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#ifdef WITH_TIMEIT

#include <time.h>
#include "eii/utils/logger.h"

#define TIMEIT(msg, ...) { \
    clock_t t; \
    t = clock(); \
    __VA_ARGS__; \
    t = clock() - t; \
    double elapsed = ((double)t) / CLOCKS_PER_SEC; \
    LOG_INFO(msg " : elapsed=%fs", elapsed); \
}
#else
#define TIMEIT(...)
#endif // WITH_TIMEIT

#ifdef __cplusplus
}
#endif // __cplusplus
#endif // _EII_UTILS_TIMEIT_H
